
public abstract class Car extends Vehicle {
	public Car()
	{
		
	}
}
