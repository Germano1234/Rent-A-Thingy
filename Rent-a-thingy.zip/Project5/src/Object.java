
public abstract class Object implements Rentable{
	protected double rentalPrice;
	public Object()
	{
		
	}
	public abstract String toString();
}
