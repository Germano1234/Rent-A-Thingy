
public abstract class Vehicle implements Rentable{
	protected double rentalPrice;
	public Vehicle()
	{
		
	}
	public abstract String toString();
}
