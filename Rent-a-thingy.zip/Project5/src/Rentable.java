
public interface Rentable {
	double getRentalPrice();
}
